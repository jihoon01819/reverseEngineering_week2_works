package com.example.part6_mission;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.Arrays;
import java.util.List;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    private Adapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initToday();

        getDataToday();

        initYesterday();

        getDataYesterday();

        initPast();

        getDataPast();
    }

    private void initToday() {
        RecyclerView recyclerView = findViewById(R.id.recyclerView1);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(linearLayoutManager);

        adapter = new Adapter();
        recyclerView.setAdapter(adapter);
    }

    private void initYesterday() {
        RecyclerView recyclerView2 = findViewById(R.id.recyclerView2);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        recyclerView2.setLayoutManager(linearLayoutManager);

        adapter = new Adapter();
        recyclerView2.setAdapter(adapter);
    }

    private void initPast() {
        RecyclerView recyclerView3 = findViewById(R.id.recyclerView3);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        recyclerView3.setLayoutManager(linearLayoutManager);

        adapter = new Adapter();
        recyclerView3.setAdapter(adapter);
    }

    private void getDataToday() {
        List<String> listName = Arrays.asList("안영주", "최은경", "최호성");
        List<String> listPhone = Arrays.asList("2019-07-01", "2019-07-01", "2019-07-01");

        for (int i = 0; i < listName.size(); i++) {
            data data = new data();
            data.setName(listName.get(i));
            data.setPhone(listPhone.get(i));

            adapter.addItem(data);
        }


        adapter.notifyDataSetChanged();


    }

    private void getDataYesterday() {
        List<String> listName = Arrays.asList("정성택", "정길용");
        List<String> listPhone = Arrays.asList("2019-06-30", "2019-06-30");

        for (int i = 0; i < listName.size(); i++) {
            data data = new data();
            data.setName(listName.get(i));
            data.setPhone(listPhone.get(i));

            adapter.addItem(data);
        }


        adapter.notifyDataSetChanged();


    }

    private void getDataPast() {
        List<String> listName = Arrays.asList("채규태", "원형섭");
        List<String> listPhone = Arrays.asList("2019-06-28", "2019-06-28");

        for (int i = 0; i < listName.size(); i++) {
            data data = new data();
            data.setName(listName.get(i));
            data.setPhone(listPhone.get(i));

            adapter.addItem(data);
        }


        adapter.notifyDataSetChanged();


    }
}